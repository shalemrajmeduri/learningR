# School Distance Calculator

This Python script calculates the distance (in km) from your home to a list of schools using geopy and the Haversine formula.

## Files

- `distance_calculator.py` – Main Python script
- `schools.txt` – List of schools (one per line)
- `README.md` – Instructions

## Instructions

1. Install required package:
    ```
    pip install geopy
    ```

2. Update your home address in `distance_calculator.py`:
    ```python
    home_address = "Your home location here"
    ```

3. Run the script:
    ```
    python distance_calculator.py
    ```
