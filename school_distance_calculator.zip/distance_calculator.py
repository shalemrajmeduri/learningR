from geopy.geocoders import Nominatim
from math import radians, sin, cos, sqrt, atan2
import time

# Haversine formula to calculate distance in km
def haversine_distance(lat1, lon1, lat2, lon2):
    R = 6371.0
    lat1_rad, lon1_rad = radians(lat1), radians(lon1)
    lat2_rad, lon2_rad = radians(lat2), radians(lon2)
    dlat = lat2_rad - lat1_rad
    dlon = lon2_rad - lon1_rad
    a = sin(dlat / 2)**2 + cos(lat1_rad) * cos(lat2_rad) * sin(dlon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return R * c

# Initialize geolocator
geolocator = Nominatim(user_agent="distance-calculator")

# Step 1: Your home location
home_address = "NTR Circle, Vijayawada"  # Change to your exact location
home_location = geolocator.geocode(home_address)

if not home_location:
    print("Could not geocode your home address.")
    exit()

home_lat, home_lon = home_location.latitude, home_location.longitude
print(f"Home Coordinates: {home_lat}, {home_lon}\n")

# Step 2: Load school names from text file
try:
    with open("schools.txt", "r", encoding="utf-8") as f:
        school_names = [line.strip() for line in f if line.strip()]
except FileNotFoundError:
    print("schools.txt not found.")
    exit()

# Step 3: Calculate distances
print("Distances to schools:\n")
for school in school_names:
    try:
        location = geolocator.geocode(school + ", Andhra Pradesh")  # improve accuracy
        if location:
            dist = haversine_distance(home_lat, home_lon, location.latitude, location.longitude)
            print(f"{school}: {dist:.2f} km")
        else:
            print(f"{school}: Location not found.")
    except Exception as e:
        print(f"Error processing {school}: {e}")
    time.sleep(1)
